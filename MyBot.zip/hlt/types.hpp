#pragma once

namespace hlt {
    typedef int Halite;
    typedef int PlayerId;
    typedef int EntityId;
}
